/* ============================================================
   PORTFOLIO DATA
   ------------------------------------------------------------
   Edit everything in this file to update the website content.
   You never need to touch index.html or the CSS to add or
   change information — just edit the objects/arrays below.
   ============================================================ */

const PORTFOLIO_DATA = {

  profile: {
    name: "Rohan Gabhane",
    fullName: "Rohan Ashok Gabhane",
    title: "Electronics & Telecommunication Engineering Student",
    tagline: "Building at the intersection of electronics, VLSI, communication systems and software.",
    email: "rohanashokgabhane@gmail.com",
    location: "Yavatmal, Maharashtra, India",
    linkedin: "https://www.linkedin.com/in/rohan-gabhane-a72641361/",
    instagram: "https://www.instagram.com/rohan_gabhane/",
    // Replace with your real GitHub profile URL once you have one.
    github: "https://github.com/your-username",
    resumeFile: "resume/Rohan_Gabhane_Resume_ready.pdf",
    // Replace with a real headshot: assets/profile-photo.jpg (recommended 600x600 or larger, square).
    photo: null,
  },

  about: `I'm an Electronics & Telecommunication Engineering student at Jawaharlal
  Darda Institute of Engineering & Technology, Yavatmal, currently in my final
  year. My core interest sits at the overlap of electronics and software —
  I've worked across embedded systems and IoT (ESP32, Arduino, sensor
  integration), digital VLSI design (completed an NPTEL course in CMOS
  Digital VLSI Design), and application development spanning Python,
  Flutter, and web technologies.

  Most of what I know, I've learned by building: an IoT-based motor health
  monitoring system with automated report generation, a garage management
  Android app used with real inventory and invoicing logic, a smart-farming
  platform that combines AI image analysis with multilingual support, and a
  secure file-sharing system built around AES-256 encryption and image
  steganography. I've also presented research work on thermal reliability
  challenges in SiC/GaN power devices for EV fast-charging systems.

  I'm an active member of IETE and Cloud Clubs JDIET, and I've taken part in
  hackathons and technical competitions across several institutions —
  Swarajya Hack Fest, NIT Hackathon AXIS26, Symbiosis SITNovate, and others.
  I'm looking for internship and placement opportunities where I can keep
  building real systems, not just studying them.`,

  education: [
    {
      degree: "Bachelor of Engineering — Electronics & Telecommunication Engineering",
      institution: "Jawaharlal Darda Institute of Engineering & Technology, Yavatmal",
      university: "Sant Gadge Baba Amravati University",
      period: "2023 – 2026 (expected)",
      detail: "Semester-wise CGPA",
      semesters: [
        { sem: "Sem I",  term: "Winter 2023", cgpa: "7.12" },
        { sem: "Sem II", term: "Summer 2024", cgpa: "6.95" },
        { sem: "Sem III", term: "Summer 2025", cgpa: "6.60" },
        { sem: "Sem IV", term: "Summer 2025", cgpa: "7.18" },
        { sem: "Sem V", term: "Winter 2025", cgpa: "7.65" },
        { sem: "Sem VI", term: "Summer 2026", cgpa: "6.68" },
      ],
    },
    {
      degree: "HSC (12th Standard)",
      institution: "Veddharini Uccha Madhyamik Vidyalaya",
      university: "Maharashtra State Board of Secondary & Higher Secondary Education, Pune",
      period: "2023",
      detail: "71.67%",
      semesters: null,
    },
    {
      degree: "SSC (10th Standard)",
      institution: "Secondary & Higher Secondary Education, Pune",
      university: "Maharashtra State Board",
      period: "2021",
      detail: "88.20%",
      semesters: null,
    },
  ],

  skills: {
    "Embedded & IoT": ["ESP32", "Arduino", "Raspberry Pi", "Sensor Integration", "Embedded C"],
    "Programming Languages": ["Python", "C", "C++", "HTML", "CSS", "JavaScript"],
    "VLSI & Electronics": ["CMOS Digital VLSI Design", "Microwind", "Altera Quartus II", "Digital Electronics"],
    "Mobile & Backend": ["Firebase Firestore & Auth", "Node.js basics", "Flutter", "Dart"],
    "AI / APIs": ["Claude API (multimodal)"],
    "Cybersecurity": ["Cryptography (AES-256-GCM)", "Image Steganography (LSB)", "Secure File Sharing"],
    "Tools & DevOps": ["Git", "GitHub", "Netlify", "MATLAB", "Proteus"],
  },

  projects: [
    {
      title: "Secure File Sharing with Steganography",
      period: "2026",
      category: "Cybersecurity",
      tech: ["Python", "Flask", "AES-256-GCM", "LSB Steganography", "SQLite"],
      description: "A secure file-sharing system that encrypts sensitive files with AES-256-GCM authenticated encryption, then hides the encrypted payload inside cover images using LSB steganography — so the data travels invisibly and requires both detection and decryption to recover.",
      features: [
        "AES-256-GCM encryption with PBKDF2 key derivation",
        "LSB image steganography with structured payload format",
        "Live capacity calculation before embedding",
        "SHA-256 integrity verification on extraction",
        "MSE / PSNR / SSIM security & quality analysis dashboard",
      ],
      github: null,
      demo: null,
      report: null,
    },
    {
      title: "AI-Based Motor Health Monitoring System",
      period: "2024 – 2025",
      category: "Embedded",
      tech: ["ESP32", "Python", "ReportLab", "Embedded C"],
      description: "An IoT system using ESP32 to monitor motor parameters in real time with anomaly detection, built as a final-year academic project.",
      features: [
        "Real-time motor parameter monitoring via ESP32",
        "Anomaly detection logic",
        "Auto-generated 25-page academic report using ReportLab, matching institute formatting",
      ],
      github: null,
      demo: null,
      report: null,
    },
    {
      title: "Garage Manager Pro",
      period: "2024",
      category: "Software",
      tech: ["Flutter", "Firebase", "Dart", "Netlify"],
      description: "A production-ready Android application for motorcycle garages, handling job cards, customer management, invoicing, and inventory.",
      features: [
        "Job cards and customer management",
        "PDF invoicing and WhatsApp notifications",
        "Inventory tracking with automatic stock deduction",
        "Excel export for records",
        "Web version deployed on Netlify",
      ],
      github: null,
      demo: null,
      report: null,
    },
    {
      title: "AgriVeista — Smart Farming Platform",
      period: "2024",
      category: "AI/ML",
      tech: ["HTML", "JavaScript", "Claude API", "OpenStreetMap API"],
      description: "An AI-powered farming assistant with crop disease detection, live mandi (market) prices, and multilingual support. Presented at Swarajya Hack Fest under Cloud Clubs, JDIET, as Team Matrix — selected in the top 5.",
      features: [
        "Crop disease detection via image analysis",
        "Live market (mandi) price information",
        "Multilingual support",
        "3-layer GPS fallback system for location reliability",
      ],
      github: null,
      demo: null,
      report: null,
    },
    {
      title: "SevaCare — Nearby Doctors & Hospitals",
      period: "2024",
      category: "Web Development",
      tech: ["OpenStreetMap API", "JavaScript"],
      description: "A healthcare module that fetches nearby doctors and hospitals using the OpenStreetMap API, with haversine-distance sorting and an emergency contact function.",
      features: [
        "Nearby doctor/hospital lookup via OpenStreetMap",
        "Haversine distance-based sorting",
        "Emergency contact function",
      ],
      github: null,
      demo: null,
      report: null,
    },
  ],

  research: [
    {
      title: "Thermal Reliability & Switching Loss Challenges of SiC & GaN Devices in EV Fast Charging Systems",
      event: "Advances in Science, Technology and Interdisciplinary Innovation (ICASTII-2026)",
      type: "Paper Presentation",
      date: "2026",
    },
  ],

  certifications: [
    {
      title: "CMOS Digital VLSI Design",
      provider: "NPTEL",
      type: "Online Course",
    },
    {
      title: "C Programming",
      provider: "Professional Qualification",
      type: "Course",
    },
    {
      title: "Deloitte Australia — Data Analytics Job Simulation",
      provider: "Deloitte (via Forage)",
      type: "Job Simulation",
    },
    {
      title: "SEBI Investor Awareness Test & Investor Certification Examination",
      provider: "SEBI",
      type: "Certification",
    },
  ],

  industrialTraining: [
    {
      title: "IoT Basics and Raspberry Pi–based System Design",
      organization: "Genosis",
    },
    {
      title: "Embedded Systems Training",
      organization: "Doxpro Robotics Pvt. Ltd.",
    },
  ],

  achievements: [
    { title: "Swarajya Hack Fest", detail: "Presented AgriVeista as Team Matrix — selected in the top 5.", category: "Competition" },
    { title: "NIT Hackathon AXIS26", detail: "Participated as part of a team.", category: "Hackathon" },
    { title: "Tech Ideathon 2026", detail: "Participated as Team Neurotorque (VIT Mauritius).", category: "Hackathon" },
    { title: "Symbiosis Hackathon SITNovate 2026", detail: "Participated and presented an innovative solution.", category: "Hackathon" },
    { title: "JCET Hackathon — Codeustav 1.0", detail: "Participated.", category: "Hackathon" },
    { title: "PRANETA-2026 Project Competition", detail: "Participated.", category: "Competition" },
    { title: "ABHYUDAYA 25.0 Project Competition", detail: "Participated.", category: "Competition" },
  ],

  affiliations: [
    "The Institution of Electronics & Telecommunication Engineers (IETE)",
    "Cloud Clubs JDIET — Active Member",
    "Campus Ambassador, ASOC-2026",
    "PRANETA-26 Organizing Committee",
  ],

  interests: ["Travelling", "AI/ML Applications", "VLSI", "Chess", "Hackathons", "Stock Market", "Riding Bikes"],

  journey: [
    { label: "SSC", detail: "88.20% — 2021" },
    { label: "HSC", detail: "71.67% — 2023" },
    { label: "B.E. ENTC begins", detail: "Jawaharlal Darda Institute of Engineering & Technology — 2023" },
    { label: "NPTEL Certification", detail: "CMOS Digital VLSI Design" },
    { label: "Industrial Training", detail: "Genosis & Doxpro Robotics" },
    { label: "Hackathons & Competitions", detail: "Swarajya Hack Fest, AXIS26, SITNovate, and more" },
    { label: "Paper Presentation", detail: "ICASTII-2026 — SiC/GaN thermal reliability in EV charging" },
    { label: "Final Year Projects", detail: "Motor Health Monitoring, Secure File Sharing, and more" },
  ],
};
