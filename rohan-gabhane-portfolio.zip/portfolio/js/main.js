/* ================================================================
   MAIN.JS — renders PORTFOLIO_DATA into the page and handles
   interactions (theme toggle, mobile nav, scroll reveal, filters).
   ================================================================ */

const D = PORTFOLIO_DATA;

/* ---------------- Icons (inline SVG, no external deps) ---------------- */
const ICONS = {
  linkedin: `<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M20.45 20.45h-3.56v-5.57c0-1.33-.03-3.04-1.85-3.04-1.86 0-2.15 1.45-2.15 2.94v5.67H9.34V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.38-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.07 2.07 0 110-4.13 2.07 2.07 0 010 4.13zM7.12 20.45H3.56V9h3.56v11.45z"/></svg>`,
  instagram: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="3.5"/><circle cx="17.3" cy="6.7" r="0.6" fill="currentColor" stroke="none"/></svg>`,
  github: `<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.58 2 12.25c0 4.53 2.87 8.37 6.84 9.73.5.1.68-.22.68-.49 0-.24-.01-1.04-.01-1.88-2.78.62-3.37-1.24-3.37-1.24-.45-1.18-1.11-1.5-1.11-1.5-.9-.64.07-.63.07-.63 1 .07 1.53 1.06 1.53 1.06.89 1.56 2.34 1.11 2.91.85.09-.66.35-1.11.63-1.37-2.22-.26-4.56-1.14-4.56-5.07 0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.31.1-2.73 0 0 .84-.28 2.75 1.05a9.3 9.3 0 015 0c1.91-1.33 2.75-1.05 2.75-1.05.55 1.42.2 2.47.1 2.73.64.72 1.03 1.63 1.03 2.75 0 3.94-2.34 4.8-4.57 5.06.36.32.68.94.68 1.9 0 1.37-.01 2.47-.01 2.81 0 .27.18.6.69.49A10.26 10.26 0 0022 12.25C22 6.58 17.52 2 12 2z"/></svg>`,
  email: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 6l10 7 10-7"/></svg>`,
};

function socialLinks(){
  const links = [];
  if (D.profile.linkedin) links.push(["linkedin", D.profile.linkedin, "LinkedIn"]);
  if (D.profile.github) links.push(["github", D.profile.github, "GitHub"]);
  if (D.profile.instagram) links.push(["instagram", D.profile.instagram, "Instagram"]);
  if (D.profile.email) links.push(["email", `mailto:${D.profile.email}`, "Email"]);
  return links.map(([key, href, label]) =>
    `<a href="${href}" target="${key==='email'?'_self':'_blank'}" rel="noopener" aria-label="${label}" title="${label}">${ICONS[key]}</a>`
  ).join("");
}

/* ---------------- Populate simple fields ---------------- */
document.getElementById("heroName").textContent = D.profile.name;
document.getElementById("heroTagline").textContent = D.profile.tagline;
document.getElementById("aboutText").textContent = D.about.replace(/\n\s+/g, "\n").trim();
document.getElementById("heroSocials").innerHTML = socialLinks();
document.getElementById("contactSocials").innerHTML = socialLinks();
document.getElementById("footerSocials").innerHTML = socialLinks();
document.getElementById("resumeBtnHero").href = D.profile.resumeFile;
document.getElementById("resumeNavBtn").href = D.profile.resumeFile;
document.getElementById("footerCopy").textContent = `© ${new Date().getFullYear()} ${D.profile.name}. All rights reserved.`;

if (D.profile.photo){
  document.getElementById("photoFrame").innerHTML = `<img src="${D.profile.photo}" alt="${D.profile.name}">`;
}

document.getElementById("footerLinks").innerHTML = [
  ["About","#about"], ["Education","#education"], ["Skills","#skills"],
  ["Projects","#projects"], ["Achievements","#achievements"], ["Research","#research"],
  ["Certifications","#certifications"], ["Contact","#contact"],
].map(([label, href]) => `<a href="${href}">${label}</a>`).join("");

/* ---------------- Education ---------------- */
document.getElementById("eduTimeline").innerHTML = D.education.map(edu => `
  <div class="edu-item">
    <div class="edu-card">
      <div class="edu-degree">${edu.degree}</div>
      <div class="edu-meta">${edu.institution}</div>
      <div class="edu-meta">${edu.university}</div>
      <span class="edu-period">${edu.period} ${edu.semesters ? '' : '· ' + edu.detail}</span>
      ${edu.semesters ? `
        <table class="sem-table">
          <thead><tr><th>Semester</th><th>Term</th><th>CGPA</th></tr></thead>
          <tbody>
            ${edu.semesters.map(s => `<tr><td>${s.sem}</td><td>${s.term}</td><td>${s.cgpa}</td></tr>`).join("")}
          </tbody>
        </table>` : ''}
    </div>
  </div>
`).join("");

/* ---------------- Skills ---------------- */
document.getElementById("skillsGrid").innerHTML = Object.entries(D.skills).map(([category, items]) => `
  <div class="skill-card">
    <h3>${category}</h3>
    <div class="skill-tags">${items.map(s => `<span class="skill-tag">${s}</span>`).join("")}</div>
  </div>
`).join("");

/* ---------------- Projects ---------------- */
const projectCategories = ["All", ...new Set(D.projects.map(p => p.category))];
document.getElementById("projectFilters").innerHTML = projectCategories.map((cat, i) =>
  `<button class="filter-btn ${i===0?'active':''}" data-filter="${cat}">${cat}</button>`
).join("");

function renderProjects(filter = "All"){
  const list = filter === "All" ? D.projects : D.projects.filter(p => p.category === filter);
  document.getElementById("projectsGrid").innerHTML = list.map(p => `
    <div class="project-card">
      <div class="project-top">
        <span class="project-title">${p.title}</span>
        <span class="project-period mono">${p.period}</span>
      </div>
      <span class="project-cat">${p.category}</span>
      <p class="project-desc">${p.description}</p>
      ${p.features ? `<ul class="project-features">${p.features.map(f => `<li>${f}</li>`).join("")}</ul>` : ''}
      <div class="project-tech">${p.tech.map(t => `<span class="tech-chip">${t}</span>`).join("")}</div>
      ${(p.github || p.demo || p.report) ? `
        <div class="project-links">
          ${p.github ? `<a href="${p.github}" target="_blank" rel="noopener">GitHub →</a>` : ''}
          ${p.demo ? `<a href="${p.demo}" target="_blank" rel="noopener">Live Demo →</a>` : ''}
          ${p.report ? `<a href="${p.report}" target="_blank" rel="noopener">Report →</a>` : ''}
        </div>` : ''}
    </div>
  `).join("");
}
renderProjects();

document.getElementById("projectFilters").addEventListener("click", (e) => {
  const btn = e.target.closest(".filter-btn");
  if (!btn) return;
  document.querySelectorAll("#projectFilters .filter-btn").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  renderProjects(btn.dataset.filter);
});

/* ---------------- Achievements ---------------- */
document.getElementById("achvGrid").innerHTML = D.achievements.map(a => `
  <div class="achv-card">
    <span class="achv-cat">${a.category}</span>
    <div class="achv-title">${a.title}</div>
    <div class="achv-detail">${a.detail}</div>
  </div>
`).join("");

document.getElementById("affilList").innerHTML = D.affiliations.map(a => `<li>${a}</li>`).join("");

/* ---------------- Research ---------------- */
document.getElementById("researchList").innerHTML = D.research.map(r => `
  <div class="research-card">
    <span class="research-type">${r.type}</span>
    <div class="research-title">${r.title}</div>
    <div class="research-meta">${r.event} — ${r.date}</div>
  </div>
`).join("") || `<p style="color:var(--ink-dim);">No research entries yet.</p>`;

/* ---------------- Certifications ---------------- */
document.getElementById("certGrid").innerHTML = D.certifications.map(c => `
  <div class="cert-card">
    <div class="cert-title">${c.title}</div>
    <div class="cert-provider">${c.provider}</div>
    <div class="cert-type">${c.type}</div>
  </div>
`).join("");

document.getElementById("trainingGrid").innerHTML = D.industrialTraining.map(t => `
  <div class="cert-card">
    <div class="cert-title">${t.title}</div>
    <div class="cert-provider">${t.organization}</div>
  </div>
`).join("");

/* ---------------- Journey ---------------- */
document.getElementById("journeyTimeline").innerHTML = D.journey.map(j => `
  <div class="journey-item">
    <div class="journey-label">${j.label}</div>
    <div class="journey-detail">${j.detail}</div>
  </div>
`).join("");

/* ---------------- Theme toggle ---------------- */
const themeToggle = document.getElementById("themeToggle");
const savedTheme = localStorage.getItem("portfolio-theme");
const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
if (savedTheme === "dark" || (!savedTheme && prefersDark)){
  document.documentElement.setAttribute("data-theme", "dark");
}
themeToggle.addEventListener("click", () => {
  const isDark = document.documentElement.getAttribute("data-theme") === "dark";
  if (isDark){
    document.documentElement.removeAttribute("data-theme");
    localStorage.setItem("portfolio-theme", "light");
  } else {
    document.documentElement.setAttribute("data-theme", "dark");
    localStorage.setItem("portfolio-theme", "dark");
  }
});

/* ---------------- Mobile nav ---------------- */
const navToggle = document.getElementById("navToggle");
const navLinks = document.getElementById("navLinks");
navToggle.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  navToggle.setAttribute("aria-expanded", open);
});
navLinks.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
  navLinks.classList.remove("open");
  navToggle.setAttribute("aria-expanded", "false");
}));

/* ---------------- Active section highlight ---------------- */
const sections = document.querySelectorAll("main .section, .hero");
const navAnchors = document.querySelectorAll(".nav-links a[data-section]");
const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting){
      const id = entry.target.id;
      navAnchors.forEach(a => a.classList.toggle("active", a.dataset.section === id));
    }
  });
}, { rootMargin: "-45% 0px -50% 0px" });
sections.forEach(s => { if (s.id) sectionObserver.observe(s); });

/* ---------------- Scroll reveal ---------------- */
const revealEls = document.querySelectorAll(".reveal");
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting){
      entry.target.classList.add("in-view");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });
revealEls.forEach(el => revealObserver.observe(el));

/* ---------------- Contact form → mailto fallback ---------------- */
document.getElementById("contactForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const name = document.getElementById("cName").value;
  const email = document.getElementById("cEmail").value;
  const subject = document.getElementById("cSubject").value;
  const message = document.getElementById("cMessage").value;
  const body = `From: ${name} (${email})\n\n${message}`;
  window.location.href = `mailto:${D.profile.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
});
